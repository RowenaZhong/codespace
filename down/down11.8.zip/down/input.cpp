#include <bits/stdc++.h>
using namespace std;
int read(){
	static int x; static char ch; x = 0,ch = getchar();
	while (!isdigit(ch)) ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0',ch = getchar();
	return x;
}
int main(){
	
	return 0;
}
